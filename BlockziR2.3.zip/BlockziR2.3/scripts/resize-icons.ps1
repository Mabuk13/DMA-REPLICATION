Add-Type -AssemblyName System.Drawing
$sourceFiles = @('icons\\toolbar-logo.png', 'icons\\site-guard-logo.png')
$destSizes = @(16, 32)
foreach ($src in $sourceFiles) {
    $image = [System.Drawing.Image]::FromFile($src)
    $baseName = [System.IO.Path]::GetFileNameWithoutExtension($src)
    $dir = [System.IO.Path]::GetDirectoryName($src)
    foreach ($size in $destSizes) {
        $bmp = New-Object System.Drawing.Bitmap $size, $size
        $g = [System.Drawing.Graphics]::FromImage($bmp)
        $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
        $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
        $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
        $g.DrawImage($image, 0, 0, $size, $size)
        $g.Dispose()
        $dest = [System.IO.Path]::Combine($dir, "$baseName-$size.png")
        $bmp.Save($dest, [System.Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose()
        Write-Host "Saved $dest"
    }
    $image.Dispose()
}
