const fs = require('fs');
const path = require('path');
const files = ['icons/toolbar-logo.png','icons/site-guard-logo.png'];
for (const file of files) {
  const p = path.join(__dirname, '..', file);
  if (!fs.existsSync(p)) {
    console.log(file, 'MISSING');
    continue;
  }
  const b = fs.readFileSync(p);
  const header = b.slice(0, 8).toString('hex');
  const w = b.readUInt32BE(16);
  const h = b.readUInt32BE(20);
  console.log(file, 'header', header, 'size', `${w}x${h}`);
}
