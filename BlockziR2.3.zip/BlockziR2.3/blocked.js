// The original address is in the hash so all normal URL components survive.
const site = location.hash ? location.hash.slice(1) : document.referrer;
const category = new URLSearchParams(location.search).get("category") || "Block list";
const website = document.querySelector("#website");
document.querySelector("#category").textContent = category;
try {
  const parsed = new URL(site);
  if (!/^https?:$/.test(parsed.protocol)) throw new Error("Unsupported protocol");
  website.textContent = site;
  website.href = site;
} catch {
  website.textContent = "A website in your blocked list";
  website.removeAttribute("href");
}
