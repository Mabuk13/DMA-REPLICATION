import { SITE_LISTS } from "./site-lists.js";

const DEFAULT_SETTINGS = {
  schemaVersion: 2,
  enabled: true,
  categories: {
    social: true,
    entertainment: true,
    games: true,
    adult: true
  },
  customDomains: []
};

const CATEGORY_LABELS = {
  social: "Social media",
  entertainment: "Streaming & entertainment",
  games: "Games",
  adult: "Adult websites",
  custom: "Custom block list"
};

async function getSettings() {
  const stored = await chrome.storage.sync.get(DEFAULT_SETTINGS);
  return {
    ...DEFAULT_SETTINGS,
    ...stored,
    categories: { ...DEFAULT_SETTINGS.categories, ...(stored.categories || {}) },
    customDomains: Array.isArray(stored.customDomains) ? stored.customDomains : []
  };
}

function normaliseDomain(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/^https?:\/\//, "")
    .replace(/^www\./, "")
    .split("/")[0]
    .replace(/[^a-z0-9.-]/g, "");
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function makeRule(id, domain, category) {
  const escapedDomain = escapeRegex(domain);
  return {
    id,
    priority: 1,
    action: {
      type: "redirect",
      // The original URL goes in the fragment, preserving paths, query
      // parameters, and URL fragments. Category stays in the normal query.
      redirect: {
        regexSubstitution: chrome.runtime.getURL(`blocked.html?category=${encodeURIComponent(category)}#\\1`)
      }
    },
    condition: {
      regexFilter: `^(https?://(?:[^/]*\\.)?${escapedDomain}(?::[0-9]+)?(?:[/?#].*)?)$`,
      resourceTypes: ["main_frame"]
    }
  };
}

async function applyRules() {
  const settings = await getSettings();
  const oldRules = await chrome.declarativeNetRequest.getDynamicRules();
  const removeRuleIds = oldRules.map((rule) => rule.id);

  if (!settings.enabled) {
    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules: [] });
    await updateBadge(settings);
    return;
  }

  const domains = new Map();
  settings.customDomains.map(normaliseDomain).filter(Boolean).forEach((domain) => {
    domains.set(domain, CATEGORY_LABELS.custom);
  });
  for (const [category, enabled] of Object.entries(settings.categories)) {
    if (enabled) (SITE_LISTS[category] || []).forEach((domain) => {
      if (!domains.has(domain)) domains.set(domain, CATEGORY_LABELS[category] || "Blocked website");
    });
  }

  const addRules = [...domains].slice(0, 5000).map(([domain, category], index) => makeRule(index + 1, domain, category));
  await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
  await updateBadge(settings, addRules.length);
}

// Storage changes can originate from the popup, options page, or Chrome Sync.
// Queue updates so two changes never try to edit the dynamic rule set at once.
let pendingApply = Promise.resolve();
function scheduleApply() {
  pendingApply = pendingApply.catch(() => undefined).then(applyRules);
  return pendingApply;
}

async function updateToolbarIcon(enabled) {
  if (!chrome?.action?.setIcon) return;
  try {
    await chrome.action.setIcon({
      path: enabled
        ? { 16: "icons/toolbar-logo-16.png", 32: "icons/toolbar-logo-32.png" }
        : { 16: "icons/site-guard-logo-16.png", 32: "icons/site-guard-logo-32.png" }
    });
  } catch (error) {
    console.error("Failed to update toolbar icon", { enabled, error });
  }
}

async function updateBadge(settings, ruleCount) {
  try {
    await chrome.action.setBadgeText({ text: "" });
    await chrome.action.setTitle({ title: `Blockzi ${settings.enabled ? "enabled" : "disabled"}` });
    await updateToolbarIcon(settings.enabled);
  } catch (error) {
    console.error("Failed to update toolbar badge/title/icon", error);
  }
}

async function toggleFiltering() {
  const settings = await getSettings();
  await chrome.storage.sync.set({ enabled: !settings.enabled });
  await scheduleApply();
}

chrome.action.onClicked.addListener(() => {
  toggleFiltering().catch(() => undefined);
});

chrome.runtime.onInstalled.addListener(async () => {
  const current = await chrome.storage.sync.get();
  if (!Object.keys(current).length) {
    await chrome.storage.sync.set(DEFAULT_SETTINGS);
  } else if (!current.schemaVersion) {
    // Version 1 shipped with Games off by default. Enable the expanded games
    // list once for existing installs, while keeping every later user choice.
    await chrome.storage.sync.set({
      schemaVersion: 2,
      categories: { ...DEFAULT_SETTINGS.categories, ...(current.categories || {}), games: true }
    });
  }
  await scheduleApply();
});

chrome.runtime.onStartup.addListener(scheduleApply);
chrome.storage.onChanged.addListener((_changes, area) => {
  if (area === "sync") scheduleApply();
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "applyRules") {
    scheduleApply().then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});

// Refresh dynamic rules whenever Chrome starts this service worker, including
// after an unpacked-extension reload during development.
scheduleApply().catch(() => undefined);
