// Edit these arrays to change the built-in blocked sites.
// One domain blocks that domain and every subdomain (for example, poki.com
// also blocks www.poki.com). Custom sites added in the extension settings are
// stored separately, so they will not be overwritten when this file changes.
export const SITE_LISTS = {
  social: [
    "facebook.com", "instagram.com", "tiktok.com", "x.com", "twitter.com",
    "snapchat.com", "reddit.com", "discord.com"
  ],
  entertainment: ["netflix.com", "hulu.com", "twitch.tv", "disneyplus.com"],
  games: [
    "poki.com", "crazygames.com", "coolmathgames.com", "y8.com", "gamepix.com",
    "kizi.com", "miniplay.com", "armorgames.com", "kongregate.com", "addictinggames.com",
    "agame.com", "freegames.org", "primarygames.com", "mathplayground.com", "pbskids.org",
    "nick.com", "friv.com", "roblox.com", "minecraft.net", "steampowered.com", "epicgames.com"
  ],
  adult: ["pornhub.com", "xvideos.com", "xnxx.com", "redtube.com", "youporn.com"]
};
