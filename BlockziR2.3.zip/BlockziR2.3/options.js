const labels = {
  social: ["Social media", "Facebook, Instagram, TikTok, Reddit, Discord and more"],
  entertainment: ["Streaming & entertainment", "YouTube, Netflix, Twitch, Spotify and more"],
  games: ["Games", "Poki, Coolmath Games, Roblox, Steam, Friv and more"],
  adult: ["Adult websites", "A small built-in list of adult sites"]
};
let settings;
const domainInput = document.querySelector("#domain");
const error = document.querySelector("#error");

function normaliseDomain(value) {
  return value.trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0].replace(/[^a-z0-9.-]/g, "");
}
function validDomain(domain) { return /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/i.test(domain); }
function flashSaved() { const node = document.querySelector("#saved"); node.textContent = "Saved"; setTimeout(() => { node.textContent = ""; }, 1600); }
async function save() { await chrome.storage.sync.set(settings); await chrome.runtime.sendMessage({ type: "applyRules" }); flashSaved(); }

function renderCategories() {
  const container = document.querySelector("#categories");
  container.replaceChildren(...Object.entries(labels).map(([key, [title, description]]) => {
    const label = document.createElement("label"); label.className = "check-row";
    label.innerHTML = `<span><strong>${title}</strong><small>${description}</small></span><input type="checkbox" data-category="${key}">`;
    const input = label.querySelector("input"); input.checked = settings.categories[key];
    input.addEventListener("change", async () => { settings.categories[key] = input.checked; await save(); });
    return label;
  }));
}
function renderDomains() {
  const list = document.querySelector("#domains"); list.replaceChildren(...settings.customDomains.map((domain) => {
    const li = document.createElement("li"); li.textContent = domain;
    const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "Remove"; remove.className = "link-button";
    remove.addEventListener("click", async () => { settings.customDomains = settings.customDomains.filter((item) => item !== domain); await save(); renderDomains(); });
    li.append(remove); return li;
  }));
}
async function init() {
  settings = await chrome.storage.sync.get({ enabled: true, categories: { social: true, entertainment: true, games: true, adult: true }, customDomains: [] });
  document.querySelector("#enabled").checked = settings.enabled;
  document.querySelector("#enabled").addEventListener("change", async (event) => { settings.enabled = event.target.checked; await save(); });
  renderCategories(); renderDomains();
}
document.querySelector("#domain-form").addEventListener("submit", async (event) => {
  event.preventDefault(); error.textContent = ""; const domain = normaliseDomain(domainInput.value);
  if (!validDomain(domain)) { error.textContent = "Enter a valid domain, like example.com."; return; }
  if (settings.customDomains.includes(domain)) { error.textContent = "That website is already on your list."; return; }
  settings.customDomains.push(domain); domainInput.value = ""; await save(); renderDomains();
});
init();
