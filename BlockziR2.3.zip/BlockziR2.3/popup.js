const enabled = document.querySelector("#enabled");
const status = document.querySelector("#status");
const summary = document.querySelector("#summary");

async function render() {
  const data = await chrome.storage.sync.get({ enabled: true, categories: {}, customDomains: [] });
  const rules = await chrome.declarativeNetRequest.getDynamicRules();
  enabled.checked = data.enabled;
  status.textContent = data.enabled ? "Filtering is on" : "Filtering is off";
  summary.textContent = data.enabled ? `${rules.length} website rules active` : "No websites are currently blocked";
}

enabled.addEventListener("change", async () => {
  await chrome.storage.sync.set({ enabled: enabled.checked });
  await chrome.runtime.sendMessage({ type: "applyRules" });
  await render();
});
document.querySelector("#settings").addEventListener("click", () => chrome.runtime.openOptionsPage());
render();
